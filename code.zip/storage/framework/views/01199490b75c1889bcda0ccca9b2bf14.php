<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SIAPU — Kelurahan Kadubeureum</title>
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=plus-jakarta-sans:400,500,600,700,800,900&display=swap" rel="stylesheet" />
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: #FAFAFA; color: #1A1A2E; }

        /* ── NAV ─────────────────────────────────── */
        .navbar {
            position: fixed; top: 0; left: 0; right: 0; z-index: 100;
            padding: 0 40px; height: 68px;
            display: flex; align-items: center; justify-content: space-between;
            background: rgba(255,255,255,0.88); backdrop-filter: blur(16px);
            border-bottom: 1px solid rgba(0,0,0,0.07);
        }
        .nav-brand { display: flex; align-items: center; gap: 12px; text-decoration: none; }
        .nav-logo {
            width: 38px; height: 38px; border-radius: 9px;
            background: #0B1F3A;
            display: flex; align-items: center; justify-content: center;
            font-weight: 900; color: #fff; font-size: 16px;
        }
        .nav-name { font-weight: 800; font-size: 16px; color: #0B1F3A; letter-spacing: -0.3px; }
        .nav-links { display: flex; align-items: center; gap: 32px; }
        .nav-links a { color: #475569; font-size: 14px; font-weight: 500; text-decoration: none; transition: color 0.15s; }
        .nav-links a:hover { color: #0B1F3A; }
        .nav-cta {
            background: #0B1F3A; color: #fff; padding: 9px 20px;
            border-radius: 8px; font-weight: 700; font-size: 13.5px;
            text-decoration: none; transition: background 0.15s;
        }
        .nav-cta:hover { background: #1E3A5F; color: #fff; }

        /* ── HERO ────────────────────────────────── */
        .hero {
            min-height: 100vh;
            background: #0B1F3A;
            display: flex; align-items: center;
            padding: 120px 40px 80px;
            position: relative; overflow: hidden;
        }
        .hero-glow-1 {
            position: absolute; top: -100px; right: 5%;
            width: 500px; height: 500px; border-radius: 50%;
            background: radial-gradient(circle, rgba(59,130,246,0.25) 0%, transparent 65%);
            pointer-events: none;
        }
        .hero-glow-2 {
            position: absolute; bottom: -80px; left: 10%;
            width: 380px; height: 380px; border-radius: 50%;
            background: radial-gradient(circle, rgba(99,102,241,0.15) 0%, transparent 65%);
            pointer-events: none;
        }
        .hero-grid {
            display: grid; grid-template-columns: 1fr 1fr; gap: 60px;
            max-width: 1200px; margin: 0 auto; align-items: center;
            position: relative; z-index: 1;
        }
        .hero-eyebrow {
            display: inline-flex; align-items: center; gap: 8px;
            background: rgba(59,130,246,0.15); border: 1px solid rgba(59,130,246,0.3);
            padding: 5px 14px; border-radius: 20px;
            color: #93C5FD; font-size: 12px; font-weight: 600; letter-spacing: 0.5px;
            margin-bottom: 20px;
        }
        .hero-eyebrow::before { content: '●'; font-size: 8px; color: #60A5FA; }
        .hero h1 {
            color: #fff; font-size: 52px; font-weight: 900; line-height: 1.1;
            letter-spacing: -1.5px; margin-bottom: 22px;
        }
        .hero h1 .accent {
            background: linear-gradient(90deg, #60A5FA, #A78BFA);
            -webkit-background-clip: text; -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .hero p {
            color: rgba(255,255,255,0.55); font-size: 17px; line-height: 1.7;
            margin-bottom: 36px; max-width: 480px;
        }
        .hero-actions { display: flex; gap: 12px; flex-wrap: wrap; }
        .btn-hero-primary {
            background: #2563EB; color: #fff;
            padding: 13px 26px; border-radius: 10px;
            font-weight: 700; font-size: 15px; text-decoration: none;
            box-shadow: 0 0 0 3px rgba(37,99,235,0.3);
            transition: all 0.2s; display: inline-flex; align-items: center; gap: 8px;
        }
        .btn-hero-primary:hover { background: #1D4ED8; box-shadow: 0 0 0 5px rgba(37,99,235,0.25); transform: translateY(-2px); }
        .btn-hero-ghost {
            background: rgba(255,255,255,0.07); color: rgba(255,255,255,0.85);
            padding: 13px 26px; border-radius: 10px; border: 1px solid rgba(255,255,255,0.15);
            font-weight: 600; font-size: 15px; text-decoration: none;
            transition: all 0.2s; display: inline-flex; align-items: center; gap: 8px;
        }
        .btn-hero-ghost:hover { background: rgba(255,255,255,0.12); color: #fff; }

        /* ── Hero right panel ─────────────────────── */
        .hero-panel {
            background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.1);
            border-radius: 20px; padding: 28px; backdrop-filter: blur(10px);
        }
        .hero-panel-title { color: rgba(255,255,255,0.4); font-size: 11px; font-weight: 700; letter-spacing: 1px; text-transform: uppercase; margin-bottom: 20px; }
        .panel-item {
            display: flex; align-items: center; gap: 14px;
            padding: 14px 16px; border-radius: 12px;
            background: rgba(255,255,255,0.04); margin-bottom: 10px;
            border: 1px solid rgba(255,255,255,0.06);
        }
        .panel-icon { width: 40px; height: 40px; border-radius: 10px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
        .panel-icon svg { width: 18px; height: 18px; }
        .panel-label { color: rgba(255,255,255,0.7); font-size: 13px; font-weight: 600; }
        .panel-sub { color: rgba(255,255,255,0.3); font-size: 11px; }
        .panel-check { margin-left: auto; }
        .panel-check svg { width: 18px; height: 18px; color: #34D399; }

        .hero-stat-row { display: flex; gap: 10px; margin-top: 16px; }
        .hero-stat {
            flex: 1; background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.08);
            border-radius: 12px; padding: 14px;
        }
        .hero-stat strong { display: block; color: #fff; font-size: 20px; font-weight: 800; }
        .hero-stat span { color: rgba(255,255,255,0.35); font-size: 11px; }

        /* ── SERVICES ─────────────────────────────── */
        .services { padding: 100px 40px; background: #fff; }
        .section-header { text-align: center; max-width: 560px; margin: 0 auto 60px; }
        .section-label {
            display: inline-block; font-size: 11.5px; font-weight: 700; letter-spacing: 1.5px;
            text-transform: uppercase; color: #2563EB; margin-bottom: 12px;
        }
        .section-title { font-size: 36px; font-weight: 900; color: #0B1F3A; letter-spacing: -0.8px; margin-bottom: 14px; line-height: 1.15; }
        .section-desc { color: #64748B; font-size: 15px; line-height: 1.7; }

        .services-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; max-width: 1200px; margin: 0 auto; }
        .service-card {
            border: 1.5px solid #E2E8F0; border-radius: 18px; padding: 30px;
            transition: all 0.2s; background: #fff;
        }
        .service-card:hover { border-color: #BFDBFE; box-shadow: 0 8px 32px rgba(37,99,235,0.08); transform: translateY(-4px); }
        .service-num { font-size: 11px; font-weight: 700; color: #CBD5E1; letter-spacing: 1px; margin-bottom: 16px; }
        .service-icon { width: 52px; height: 52px; border-radius: 14px; display: flex; align-items: center; justify-content: center; margin-bottom: 18px; }
        .service-icon svg { width: 24px; height: 24px; }
        .service-title { font-size: 17px; font-weight: 800; color: #0F172A; margin-bottom: 10px; }
        .service-desc { color: #64748B; font-size: 14px; line-height: 1.65; margin-bottom: 20px; }
        .service-link { color: #2563EB; font-size: 13.5px; font-weight: 700; text-decoration: none; display: inline-flex; align-items: center; gap: 4px; }
        .service-link:hover { gap: 8px; }

        /* ── HOW IT WORKS ─────────────────────────── */
        .how { padding: 100px 40px; background: #F8FAFC; }
        .steps { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 24px; max-width: 1100px; margin: 0 auto; }
        .step { text-align: center; padding: 28px 20px; }
        .step-num {
            width: 56px; height: 56px; border-radius: 50%;
            background: #0B1F3A; color: #fff; font-size: 20px; font-weight: 900;
            display: flex; align-items: center; justify-content: center; margin: 0 auto 16px;
        }
        .step h4 { font-size: 15px; font-weight: 700; color: #0F172A; margin-bottom: 8px; }
        .step p { color: #64748B; font-size: 13.5px; line-height: 1.6; }

        /* ── FOOTER ───────────────────────────────── */
        footer { background: #0B1F3A; padding: 56px 40px 32px; }
        .footer-inner { max-width: 1200px; margin: 0 auto; }
        .footer-brand { display: flex; align-items: center; gap: 12px; margin-bottom: 12px; }
        .footer-logo {
            width: 38px; height: 38px; border-radius: 9px; background: rgba(255,255,255,0.1);
            display: flex; align-items: center; justify-content: center;
            font-weight: 900; color: #fff; font-size: 16px;
        }
        .footer-name { font-size: 16px; font-weight: 800; color: #fff; }
        footer p { color: rgba(255,255,255,0.35); font-size: 13px; max-width: 460px; line-height: 1.6; margin-bottom: 32px; }
        .footer-bottom { border-top: 1px solid rgba(255,255,255,0.08); padding-top: 24px; color: rgba(255,255,255,0.2); font-size: 12px; }

        @media (max-width: 768px) {
            .hero-grid { grid-template-columns: 1fr; }
            .hero-panel { display: none; }
            .hero h1 { font-size: 36px; }
            .navbar { padding: 0 20px; }
            .nav-links { display: none; }
        }
    </style>
</head>
<body>

<nav class="navbar">
    <a href="#" class="nav-brand">
        <div class="nav-logo">K</div>
        <span class="nav-name">KADUBEUREUM</span>
    </a>
    <div class="nav-links">
        <a href="#layanan">Layanan</a>
        <a href="#cara-kerja">Cara Kerja</a>
        <a href="<?php echo e(route('public.cek_status')); ?>">Cek Status</a>
        <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(url('/dashboard')); ?>" class="nav-cta">Dashboard</a>
        <?php else: ?>
            <a href="<?php echo e(route('login')); ?>" class="nav-cta">Login Admin</a>
        <?php endif; ?>
    </div>
</nav>

<!-- HERO -->
<section class="hero">
    <div class="hero-glow-1"></div>
    <div class="hero-glow-2"></div>
    <div class="hero-grid">
        <div>
            <div class="hero-eyebrow">SIAPU &mdash; Sistem Administrasi Digital</div>
            <h1>Layanan <span class="accent">Kelurahan</span> dari Rumah Anda</h1>
            <p>Ajukan surat administrasi, cek status permohonan, dan lihat informasi BLT &mdash; semua tanpa perlu datang ke kantor kelurahan.</p>
            <div class="hero-actions">
                <a href="<?php echo e(route('public.layanan_mandiri')); ?>" class="btn-hero-primary">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" style="width:17px;height:17px;"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                    Buat Pengajuan
                </a>
                <a href="<?php echo e(route('public.cek_status')); ?>" class="btn-hero-ghost">
                    Cek Status Saya
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" style="width:15px;height:15px;"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
                </a>
            </div>
        </div>

        <div class="hero-panel">
            <div class="hero-panel-title">Fitur Tersedia</div>

            <div class="panel-item">
                <div class="panel-icon" style="background:rgba(59,130,246,0.15);">
                    <svg fill="none" stroke="#60A5FA" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                </div>
                <div>
                    <div class="panel-label">Surat Administrasi Online</div>
                    <div class="panel-sub">Keterangan, pengantar, domisili</div>
                </div>
                <div class="panel-check"><svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7"/></svg></div>
            </div>

            <div class="panel-item">
                <div class="panel-icon" style="background:rgba(52,211,153,0.15);">
                    <svg fill="none" stroke="#34D399" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                </div>
                <div>
                    <div class="panel-label">Lacak Status Real-time</div>
                    <div class="panel-sub">Dengan NIK, kapan saja</div>
                </div>
                <div class="panel-check"><svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7"/></svg></div>
            </div>

            <div class="panel-item">
                <div class="panel-icon" style="background:rgba(251,191,36,0.15);">
                    <svg fill="none" stroke="#FBBF24" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                </div>
                <div>
                    <div class="panel-label">Transparansi BLT</div>
                    <div class="panel-sub">Informasi terbuka untuk warga</div>
                </div>
                <div class="panel-check"><svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7"/></svg></div>
            </div>

            <div class="hero-stat-row">
                <div class="hero-stat">
                    <strong>24/7</strong>
                    <span>Akses Online</span>
                </div>
                <div class="hero-stat">
                    <strong>Gratis</strong>
                    <span>Tanpa Biaya</span>
                </div>
                <div class="hero-stat">
                    <strong>Cepat</strong>
                    <span>Terproses</span>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- SERVICES -->
<section class="services" id="layanan">
    <div class="section-header">
        <div class="section-label">Layanan Kami</div>
        <h2 class="section-title">Semua Keperluan Administrasi dalam Satu Platform</h2>
        <p class="section-desc">Tidak perlu antre berjam-jam. Ajukan permohonan dari rumah dan pantau prosesnya secara langsung.</p>
    </div>

    <div class="services-grid">
        <div class="service-card">
            <div class="service-num">01</div>
            <div class="service-icon" style="background:#EFF6FF;">
                <svg fill="none" stroke="#2563EB" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
            </div>
            <div class="service-title">Surat Administrasi Online</div>
            <p class="service-desc">Ajukan Surat Keterangan Usaha, Domisili, Pengantar Nikah, dan berbagai surat lainnya tanpa harus datang ke kantor kelurahan.</p>
            <a href="<?php echo e(route('public.layanan_mandiri')); ?>" class="service-link">Ajukan Sekarang →</a>
        </div>

        <div class="service-card">
            <div class="service-num">02</div>
            <div class="service-icon" style="background:#F0FDF4;">
                <svg fill="none" stroke="#16A34A" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            </div>
            <div class="service-title">Lacak Status Permohonan</div>
            <p class="service-desc">Pantau perkembangan pengajuan surat Anda secara langsung menggunakan Nomor Induk Kependudukan (NIK). Tidak perlu menelepon.</p>
            <a href="<?php echo e(route('public.cek_status')); ?>" class="service-link">Cek Status →</a>
        </div>

        <div class="service-card">
            <div class="service-num">03</div>
            <div class="service-icon" style="background:#FFFBEB;">
                <svg fill="none" stroke="#D97706" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            </div>
            <div class="service-title">Informasi BLT Transparan</div>
            <p class="service-desc">Warga dapat melihat sendiri data penerimaan Bantuan Langsung Tunai secara terbuka untuk mendukung transparansi dan akuntabilitas.</p>
            <a href="<?php echo e(route('public.cek_status')); ?>" class="service-link">Cek Penerimaan BLT →</a>
        </div>
    </div>
</section>

<!-- HOW IT WORKS -->
<section class="how" id="cara-kerja">
    <div class="section-header">
        <div class="section-label">Cara Kerja</div>
        <h2 class="section-title">Pengajuan Surat dalam 4 Langkah</h2>
        <p class="section-desc">Mudah, cepat, dan bisa dilakukan dari mana saja.</p>
    </div>

    <div class="steps">
        <div class="step">
            <div class="step-num">1</div>
            <h4>Isi Formulir</h4>
            <p>Masukkan NIK dan data diri Anda, lalu pilih jenis surat yang ingin diajukan.</p>
        </div>
        <div class="step">
            <div class="step-num">2</div>
            <h4>Kirim Permohonan</h4>
            <p>Permohonan Anda diterima dan masuk ke antrian verifikasi petugas kelurahan.</p>
        </div>
        <div class="step">
            <div class="step-num">3</div>
            <h4>Proses Validasi</h4>
            <p>Petugas memverifikasi data dan memproses surat sesuai prosedur yang berlaku.</p>
        </div>
        <div class="step">
            <div class="step-num">4</div>
            <h4>Surat Siap</h4>
            <p>Cek status pengajuan, dan ambil surat yang sudah jadi di kantor kelurahan.</p>
        </div>
    </div>
</section>

<!-- FOOTER -->
<footer>
    <div class="footer-inner">
        <div class="footer-brand">
            <div class="footer-logo">K</div>
            <span class="footer-name">SIAPU &mdash; Kadubeureum</span>
        </div>
        <p>Sistem Informasi Administrasi Pelayanan Umum Kelurahan Kadubeureum, Kecamatan Pabuaran, Kabupaten Serang, Banten.</p>
        <div class="footer-bottom">
            &copy; <?php echo e(date('Y')); ?> Kelurahan Kadubeureum. Hak Cipta Dilindungi.
        </div>
    </div>
</footer>

</body>
</html>
<?php /**PATH C:\laragon-6.0.0\www\000000000 PORTOFOLIO\web desa (PHP)\composer_redesigned\resources\views/welcome.blade.php ENDPATH**/ ?>