<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> Pengajuan Surat Warga <?php $__env->endSlot(); ?>

    <?php if(session('success')): ?>
        <div class="alert-success">
            <strong>Berhasil!</strong> <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">
            <h3>Daftar Permohonan Masuk</h3>
            <div style="display:flex;gap:8px;align-items:center;">
                <span class="badge badge-yellow">Menunggu: perlu dicek dari controller</span>
            </div>
        </div>

        <table class="data-table">
            <thead>
                <tr>
                    <th>Tanggal</th>
                    <th>Pemohon</th>
                    <th>Jenis Surat</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $pengajuans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td style="color:#64748B;font-size:13px;"><?php echo e(\Carbon\Carbon::parse($p->tanggal_pengajuan)->format('d M Y')); ?></td>
                    <td>
                        <div style="font-weight:600;color:#0F172A;font-size:13.5px;"><?php echo e($p->warga->nama); ?></div>
                        <div style="font-family:monospace;font-size:11.5px;color:#94A3B8;margin-top:2px;"><?php echo e($p->warga->nik); ?></div>
                    </td>
                    <td style="font-size:13.5px;"><?php echo e($p->jenisSurat->nama_surat); ?></td>
                    <td>
                        <?php
                            $statusClass = match($p->status) {
                                'Selesai'  => 'badge-green',
                                'Ditolak'  => 'badge-red',
                                'Diproses' => 'badge-blue',
                                default    => 'badge-yellow',
                            };
                        ?>
                        <span class="badge <?php echo e($statusClass); ?>"><?php echo e($p->status); ?></span>
                    </td>
                    <td>
                        <a href="<?php echo e(route('admin.pengajuan-surat.edit', $p)); ?>" class="btn btn-primary" style="padding:5px 14px;font-size:12px;">
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" style="width:13px;height:13px;"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                            Proses
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" style="text-align:center;padding:48px;color:#94A3B8;">
                        <svg style="width:42px;height:42px;margin:0 auto 10px;display:block;opacity:0.25;" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"/></svg>
                        Tidak ada pengajuan surat saat ini.
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <div style="padding:16px 22px;border-top:1px solid #F1F5F9;">
            <?php echo e($pengajuans->links()); ?>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon-6.0.0\www\000000000 PORTOFOLIO\web desa (PHP)\composer_redesigned\resources\views/admin/pengajuan_surat/index.blade.php ENDPATH**/ ?>