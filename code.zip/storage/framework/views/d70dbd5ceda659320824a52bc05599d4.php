<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\GuestLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
        .auth-form-card h2::before { content: ''; }
        .form-group { margin-bottom: 18px; }
        .form-label { display: block; font-size: 12.5px; font-weight: 600; color: #475569; margin-bottom: 6px; }
        .form-input {
            width: 100%; padding: 10px 14px;
            border: 1.5px solid #E2E8F0; border-radius: 9px;
            font-size: 14px; font-family: inherit; color: #0F172A; outline: none;
            transition: border-color 0.15s, box-shadow 0.15s;
        }
        .form-input:focus { border-color: #3B82F6; box-shadow: 0 0 0 3px rgba(59,130,246,0.12); }
        .form-error { color: #DC2626; font-size: 12px; margin-top: 4px; }
        .btn-login {
            width: 100%; padding: 11px; border-radius: 9px;
            background: #2563EB; color: #fff; font-weight: 700; font-size: 14px;
            border: none; cursor: pointer; font-family: inherit;
            transition: background 0.15s, transform 0.1s;
        }
        .btn-login:hover { background: #1D4ED8; transform: translateY(-1px); }
        .remember-row { display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px; }
        .remember-check { display: flex; align-items: center; gap: 7px; font-size: 13px; color: #64748B; }
        .remember-check input[type=checkbox] { accent-color: #2563EB; width: 15px; height: 15px; }
        .forgot-link { font-size: 12.5px; color: #3B82F6; text-decoration: none; font-weight: 600; }
        .forgot-link:hover { color: #1D4ED8; }
        .status-msg { background: #F0FDF4; border: 1px solid #BBF7D0; color: #166534; padding: 10px 14px; border-radius: 8px; font-size: 13px; margin-bottom: 18px; }
    </style>

    <h2>Selamat Datang</h2>
    <p>Masuk ke panel administrasi SIAPU Kelurahan Kadubeureum.</p>

    <?php if(session('status')): ?>
        <div class="status-msg"><?php echo e(session('status')); ?></div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label class="form-label" for="email">Alamat Email</label>
            <input id="email" class="form-input" type="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus autocomplete="username" placeholder="admin@kelurahan.go.id">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="form-error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
            <label class="form-label" for="password">Password</label>
            <input id="password" class="form-input" type="password" name="password" required autocomplete="current-password" placeholder="••••••••">
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="form-error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="remember-row">
            <label class="remember-check">
                <input type="checkbox" name="remember" id="remember_me">
                Ingat saya
            </label>
            <?php if(Route::has('password.request')): ?>
                <a class="forgot-link" href="<?php echo e(route('password.request')); ?>">Lupa password?</a>
            <?php endif; ?>
        </div>

        <button type="submit" class="btn-login">Masuk ke Dashboard</button>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php /**PATH C:\laragon-6.0.0\www\000000000 PORTOFOLIO\web desa (PHP)\resources\views/auth/login.blade.php ENDPATH**/ ?>